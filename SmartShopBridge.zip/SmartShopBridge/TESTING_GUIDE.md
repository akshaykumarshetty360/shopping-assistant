# 🧪 Testing Guide - Smart Shopping Assistant

This guide will help you test all features of the Smart Shopping Assistant application.

## 📋 Pre-Test Checklist

- ✅ Application is running at the Webview
- ✅ Sample shopping list image available: `sample_shopping_list.png`
- ✅ Camera/image upload functionality working

## 🧑‍💼 Testing Customer Mode

### Test 1: Image Upload and OCR
1. Click on **Customer Mode** button
2. Select "Upload Image" option
3. Upload the `sample_shopping_list.png` file
4. Select "English" as the translation language
5. Click "Extract & Process List" button

**Expected Results:**
- ✅ Image displays correctly
- ✅ Text is extracted from the image
- ✅ Items are parsed and displayed
- ✅ Price breakdown table appears
- ✅ Total amount is calculated

### Test 2: Multi-language Translation
1. Upload a shopping list image
2. Select different languages (Hindi, Kannada, Tamil, etc.)
3. Click "Extract & Process List"

**Expected Results:**
- ✅ Extracted text is translated to selected language
- ✅ Translation appears in the "Extracted Text" expander
- ✅ Bill calculation works regardless of language

### Test 3: Camera Capture
1. Click on **Customer Mode**
2. Select "Take Photo" option
3. Allow camera access
4. Take a photo of a handwritten list
5. Process the image

**Expected Results:**
- ✅ Camera interface opens
- ✅ Photo is captured successfully
- ✅ OCR processes the captured image
- ✅ Items are recognized

### Test 4: Bill Calculation
1. Upload the sample shopping list
2. Process the image
3. Review the price breakdown table

**Expected Results:**
- ✅ Each item shows: name, quantity, price/unit, total
- ✅ Available items show ✅ status
- ✅ Unavailable items show ❌ status
- ✅ Final total is accurate
- ✅ Currency symbol (₹) displays correctly

## 🏪 Testing Shopkeeper Mode

### Test 5: View Inventory
1. Click on **Shopkeeper Mode** button
2. Navigate to "Current Inventory" tab

**Expected Results:**
- ✅ All products are listed
- ✅ Prices display correctly
- ✅ Units are shown (kg, liter, piece)
- ✅ Availability status is visible

### Test 6: Edit Existing Product
1. Go to Shopkeeper Mode → Current Inventory
2. Select a product from dropdown (e.g., "rice")
3. Change the price (e.g., from ₹50 to ₹55)
4. Click "Update Product"

**Expected Results:**
- ✅ Success message appears
- ✅ Product table refreshes
- ✅ New price is displayed
- ✅ Changes persist during session

### Test 7: Update Product Availability
1. Select a product
2. Uncheck "Available" checkbox
3. Click "Update Product"
4. Switch to Customer Mode
5. Upload a list containing that product

**Expected Results:**
- ✅ Product marked as unavailable
- ✅ In customer view, item shows ❌ status
- ✅ Item not included in total calculation

### Test 8: Add New Product
1. Go to Shopkeeper Mode → Add/Update Products tab
2. Enter product details:
   - Name: "onion"
   - Price: 30
   - Unit: kg
   - Available: checked
3. Click "Add Product"

**Expected Results:**
- ✅ Success message appears
- ✅ New product appears in inventory
- ✅ Product is available for customer searches
- ✅ Can be matched with customer lists

## 🔄 Integration Testing

### Test 9: End-to-End Workflow
1. **Shopkeeper**: Add a new product "tomato" at ₹40/kg
2. **Customer**: Create a handwritten list including "tomato"
3. **Customer**: Upload and process the list
4. **Customer**: Verify tomato appears in bill
5. **Shopkeeper**: Mark tomato as unavailable
6. **Customer**: Process the same list again

**Expected Results:**
- ✅ New product is recognized
- ✅ Price is calculated correctly
- ✅ Availability changes reflect immediately
- ✅ Bill updates accordingly

### Test 10: Multiple Items Recognition
Create a list with various formats:
```
2 kg rice
500g sugar
3 oil
bread
12 eggs
1 liter milk
```

**Expected Results:**
- ✅ Different quantity formats recognized
- ✅ Items without quantities default to 1
- ✅ All matched items show in bill
- ✅ Total is accurate

## 🌍 Translation Testing

### Test 11: Hindi Translation
1. Upload shopping list
2. Select "Hindi" language
3. Process the list

**Expected Results:**
- ✅ Text is translated to Hindi
- ✅ Bill calculation still works
- ✅ Product matching is accurate

### Test 12: Other Languages
Repeat for: Kannada, Tamil, Telugu, Malayalam, Bengali, Marathi, Gujarati

**Expected Results:**
- ✅ Translation works for all languages
- ✅ No errors occur
- ✅ Bill functionality intact

## 🐛 Edge Cases Testing

### Test 13: Empty Image
1. Upload a blank white image
2. Try to process

**Expected Results:**
- ✅ Error message appears
- ✅ App doesn't crash
- ✅ User can try again

### Test 14: Unclear Handwriting
1. Upload an image with very messy handwriting
2. Process the image

**Expected Results:**
- ✅ App attempts extraction
- ✅ Partial recognition possible
- ✅ Unmatched items show as "Not Available"

### Test 15: No Matching Products
1. Upload list with items not in database
2. Process the list

**Expected Results:**
- ✅ Items show in table
- ✅ Status shows ❌ Not Available
- ✅ Price shows N/A
- ✅ Total excludes these items

## 📊 Performance Testing

### Test 16: Large Shopping List
Create a list with 20+ items

**Expected Results:**
- ✅ Processing completes in reasonable time
- ✅ All items are processed
- ✅ Table displays correctly
- ✅ No performance issues

### Test 17: High Resolution Image
Upload a very high-resolution image (>5MB)

**Expected Results:**
- ✅ Image uploads successfully
- ✅ Processing may take longer but completes
- ✅ OCR works correctly

## ✅ Success Criteria

All tests should pass with:
- No application crashes
- Correct data processing
- Accurate calculations
- Proper error handling
- Good user experience
- Responsive interface

## 🔧 Troubleshooting

### Issue: OCR not extracting text
**Solution**: 
- Ensure tesseract is installed
- Use clearer images
- Check image has good contrast

### Issue: Translation fails
**Solution**:
- Check internet connection
- Try different language
- Fall back to English

### Issue: Items not matching
**Solution**:
- Add product to inventory first
- Check spelling in handwritten list
- Product names should be simple

---

**Happy Testing! 🎉**
