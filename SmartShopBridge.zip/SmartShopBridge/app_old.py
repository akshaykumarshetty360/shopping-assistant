import streamlit as st
import cv2
import numpy as np
from PIL import Image
import pytesseract
from deep_translator import GoogleTranslator
import pandas as pd
import io
import re

# Initialize session state
if 'mode' not in st.session_state:
    st.session_state.mode = 'customer'
if 'products' not in st.session_state:
    st.session_state.products = {
        'rice': {'price': 50, 'unit': 'kg', 'available': True},
        'wheat': {'price': 40, 'unit': 'kg', 'available': True},
        'sugar': {'price': 45, 'unit': 'kg', 'available': True},
        'tea': {'price': 150, 'unit': 'kg', 'available': True},
        'oil': {'price': 120, 'unit': 'liter', 'available': True},
        'dal': {'price': 80, 'unit': 'kg', 'available': True},
        'salt': {'price': 20, 'unit': 'kg', 'available': True},
        'milk': {'price': 60, 'unit': 'liter', 'available': True},
        'bread': {'price': 40, 'unit': 'piece', 'available': True},
        'eggs': {'price': 6, 'unit': 'piece', 'available': True},
    }
if 'extracted_items' not in st.session_state:
    st.session_state.extracted_items = []
if 'translated_text' not in st.session_state:
    st.session_state.translated_text = ''

# Language options for translation
LANGUAGES = {
    'English': 'en',
    'Hindi': 'hi',
    'Kannada': 'kn',
    'Tamil': 'ta',
    'Telugu': 'te',
    'Malayalam': 'ml',
    'Bengali': 'bn',
    'Marathi': 'mr',
    'Gujarati': 'gu'
}

def preprocess_image(image):
    """Preprocess image for better OCR results"""
    # Convert PIL image to numpy array
    img_array = np.array(image)
    
    # Convert to grayscale
    if len(img_array.shape) == 3:
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    else:
        gray = img_array
    
    # Apply thresholding to get binary image
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # Denoise
    denoised = cv2.fastNlMeansDenoising(thresh, None, 10, 7, 21)
    
    # Increase contrast
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    enhanced = clahe.apply(denoised)
    
    return enhanced

def extract_text_from_image(image):
    """Extract text from image using OCR"""
    try:
        # Preprocess the image
        processed_img = preprocess_image(image)
        
        # Perform OCR
        text = pytesseract.image_to_string(processed_img)
        
        return text
    except Exception as e:
        st.error(f"Error extracting text: {str(e)}")
        return ""

def parse_shopping_list(text):
    """Parse the extracted text to identify items and quantities"""
    items = []
    lines = text.strip().split('\n')
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # Try to extract quantity and item name
        # Pattern: number followed by unit (optional) and item name
        # Examples: "2 kg rice", "3 oil", "500g sugar"
        match = re.match(r'(\d+\.?\d*)\s*([a-zA-Z]*)\s*(.+)', line)
        
        if match:
            quantity = float(match.group(1))
            unit = match.group(2).lower() if match.group(2) else ''
            item_name = match.group(3).strip().lower()
            
            items.append({
                'quantity': quantity,
                'unit': unit,
                'item': item_name,
                'original_line': line
            })
        else:
            # If no quantity found, assume quantity is 1
            item_name = line.lower()
            items.append({
                'quantity': 1,
                'unit': '',
                'item': item_name,
                'original_line': line
            })
    
    return items

def find_matching_product(item_name, products):
    """Find matching product from the database"""
    item_name = item_name.lower().strip()
    
    # Direct match
    if item_name in products:
        return item_name
    
    # Partial match
    for product in products.keys():
        if product in item_name or item_name in product:
            return product
    
    return None

def translate_text(text, target_language):
    """Translate text to target language"""
    try:
        if target_language == 'en' or not text:
            return text
        
        translator = GoogleTranslator(source='auto', target=target_language)
        translated = translator.translate(text)
        return translated
    except Exception as e:
        st.error(f"Translation error: {str(e)}")
        return text

def calculate_bill(items, products):
    """Calculate total bill based on recognized items"""
    bill_items = []
    total = 0
    
    for item in items:
        matched_product = find_matching_product(item['item'], products)
        
        if matched_product and products[matched_product]['available']:
            price = products[matched_product]['price']
            quantity = item['quantity']
            item_total = price * quantity
            total += item_total
            
            bill_items.append({
                'Item': matched_product.title(),
                'Quantity': f"{quantity} {products[matched_product]['unit']}",
                'Price/Unit': f"₹{price}",
                'Total': f"₹{item_total:.2f}",
                'Status': '✅ Available'
            })
        else:
            bill_items.append({
                'Item': item['item'].title(),
                'Quantity': f"{item['quantity']} {item['unit']}",
                'Price/Unit': 'N/A',
                'Total': 'N/A',
                'Status': '❌ Not Available'
            })
    
    return bill_items, total

# App UI
st.set_page_config(page_title="Smart Shopping Assistant", page_icon="🛒", layout="wide")

st.title("🛒 Smart AI Shopping Assistant")
st.markdown("*Bridging the gap between customers and shopkeepers with AI-powered transparency*")

# Mode selector
col1, col2 = st.columns(2)
with col1:
    if st.button("👤 Customer Mode", width="stretch", type="primary" if st.session_state.mode == 'customer' else "secondary"):
        st.session_state.mode = 'customer'
        st.session_state.extracted_items = []
        st.session_state.translated_text = ''
        st.rerun()

with col2:
    if st.button("🏪 Shopkeeper Mode", width="stretch", type="primary" if st.session_state.mode == 'shopkeeper' else "secondary"):
        st.session_state.mode = 'shopkeeper'
        st.rerun()

st.divider()

# Customer Mode
if st.session_state.mode == 'customer':
    st.header("📸 Upload Your Handwritten Shopping List")
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("1️⃣ Capture/Upload List")
        
        # Image upload options
        upload_option = st.radio("Choose input method:", ["Upload Image", "Take Photo"])
        
        uploaded_file = None
        if upload_option == "Upload Image":
            uploaded_file = st.file_uploader("Upload handwritten list image", type=['png', 'jpg', 'jpeg'])
        else:
            uploaded_file = st.camera_input("Take a photo of your shopping list")
        
        if not uploaded_file and st.session_state.extracted_items:
            st.session_state.extracted_items = []
            st.session_state.translated_text = ''
        
        if uploaded_file:
            image = Image.open(uploaded_file)
            st.image(image, caption="Your Shopping List", width="stretch")
            
            # Language selection for translation
            st.subheader("2️⃣ Select Translation Language")
            target_language = st.selectbox(
                "Translate extracted text to:",
                options=list(LANGUAGES.keys()),
                index=0
            )
            
            if st.button("🔍 Extract & Process List", type="primary", width="stretch"):
                with st.spinner("Processing your shopping list..."):
                    # Extract text
                    extracted_text = extract_text_from_image(image)
                    
                    if extracted_text.strip():
                        st.success("✅ Text extracted successfully!")
                        
                        # Parse items
                        items = parse_shopping_list(extracted_text)
                        st.session_state.extracted_items = items
                        
                        # Translate if needed
                        if target_language != 'English':
                            translated = translate_text(extracted_text, LANGUAGES[target_language])
                            st.session_state.translated_text = translated
                        else:
                            st.session_state.translated_text = extracted_text
                    else:
                        st.error("❌ No text found. Please upload a clearer image.")
    
    with col2:
        if st.session_state.extracted_items:
            st.subheader("3️⃣ Your Shopping List")
            
            # Display extracted text
            with st.expander("📝 Extracted Text", expanded=False):
                st.text(st.session_state.translated_text if st.session_state.translated_text else "No text extracted")
            
            # Calculate and display bill
            st.subheader("💰 Price Breakdown")
            bill_items, total = calculate_bill(st.session_state.extracted_items, st.session_state.products)
            
            if bill_items:
                df = pd.DataFrame(bill_items)
                st.dataframe(df, width="stretch", hide_index=True)
                
                st.divider()
                
                # Total display
                col_a, col_b, col_c = st.columns([2, 1, 1])
                with col_c:
                    st.markdown(f"### **Total: ₹{total:.2f}**")
                
                st.success("✅ Bill generated successfully! Show this to the shopkeeper for verification.")
            else:
                st.warning("No items could be matched with available products.")

# Shopkeeper Mode
elif st.session_state.mode == 'shopkeeper':
    st.header("🏪 Shopkeeper Dashboard - Manage Inventory & Pricing")
    
    tab1, tab2 = st.tabs(["📊 Current Inventory", "➕ Add/Update Products"])
    
    with tab1:
        st.subheader("Current Products & Prices")
        
        # Display current products
        products_data = []
        for name, details in st.session_state.products.items():
            products_data.append({
                'Product': name.title(),
                'Price': f"₹{details['price']}",
                'Unit': details['unit'],
                'Available': '✅ Yes' if details['available'] else '❌ No'
            })
        
        df = pd.DataFrame(products_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        st.divider()
        
        # Edit existing products
        st.subheader("Edit Existing Products")
        
        product_to_edit = st.selectbox(
            "Select product to edit:",
            options=list(st.session_state.products.keys()),
            format_func=lambda x: x.title()
        )
        
        if product_to_edit:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                new_price = st.number_input(
                    "Price (₹)",
                    min_value=0.0,
                    value=float(st.session_state.products[product_to_edit]['price']),
                    step=1.0
                )
            
            with col2:
                new_unit = st.text_input(
                    "Unit",
                    value=st.session_state.products[product_to_edit]['unit']
                )
            
            with col3:
                new_availability = st.checkbox(
                    "Available",
                    value=st.session_state.products[product_to_edit]['available']
                )
            
            if st.button("💾 Update Product", type="primary"):
                st.session_state.products[product_to_edit] = {
                    'price': new_price,
                    'unit': new_unit,
                    'available': new_availability
                }
                st.success(f"✅ {product_to_edit.title()} updated successfully!")
                st.rerun()
    
    with tab2:
        st.subheader("Add New Product")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            new_product_name = st.text_input("Product Name").lower().strip()
        
        with col2:
            new_product_price = st.number_input("Price (₹)", min_value=0.0, step=1.0)
        
        with col3:
            new_product_unit = st.text_input("Unit (kg/liter/piece)")
        
        new_product_available = st.checkbox("Available in stock", value=True)
        
        if st.button("➕ Add Product", type="primary"):
            if new_product_name and new_product_price > 0 and new_product_unit:
                st.session_state.products[new_product_name] = {
                    'price': new_product_price,
                    'unit': new_product_unit,
                    'available': new_product_available
                }
                st.success(f"✅ {new_product_name.title()} added successfully!")
                st.rerun()
            else:
                st.error("Please fill all fields correctly.")

# Footer
st.divider()
st.markdown("""
<div style='text-align: center; color: gray; padding: 20px;'>
    <p>🤖 Powered by AI • Making shopping transparent and efficient</p>
    <p>OCR • Translation • Real-time Pricing</p>
</div>
""", unsafe_allow_html=True)
