# 🛒 Smart AI Shopping Assistant

An AI-powered shopping assistant that bridges the gap between customers and shopkeepers, making shopping more transparent and efficient.

## ✨ Features

### For Customers:
- 📸 **Handwritten List Recognition**: Upload or capture photos of handwritten shopping lists
- 🔍 **Smart OCR**: Automatically extracts items and quantities from images
- 🌐 **Multi-language Translation**: Supports Hindi, Kannada, Tamil, Telugu, Malayalam, Bengali, Marathi, and Gujarati
- 💰 **Price Transparency**: Get instant bill estimates with item-by-item breakdown
- ✅ **Availability Check**: See which items are in stock

### For Shopkeepers:
- 🏪 **Inventory Management**: Easy-to-use dashboard for managing products
- 💵 **Price Updates**: Update prices and availability in real-time
- ➕ **Product Addition**: Add new products to the inventory
- 📊 **Product Overview**: View all products with current pricing

## 🚀 How It Works

### Customer Workflow:
1. **Upload/Capture** your handwritten shopping list
2. **Select** your preferred language for translation
3. **Extract** - AI processes the image and recognizes items
4. **Review** - See your digital shopping list with prices
5. **Share** - Show the estimated bill to the shopkeeper

### Shopkeeper Workflow:
1. **Switch** to Shopkeeper Mode
2. **View** current inventory and prices
3. **Update** product prices and availability
4. **Add** new products to the system

## 🛠️ Technology Stack

- **Frontend**: Streamlit (Python web framework)
- **OCR**: Pytesseract with OpenCV preprocessing
- **Translation**: Google Translator (deep-translator)
- **Image Processing**: OpenCV, Pillow
- **Data Management**: Pandas

## 📋 Image Preprocessing

The app uses advanced image preprocessing to improve OCR accuracy:
- Grayscale conversion
- Otsu's thresholding for binarization
- Noise reduction using Non-local Means Denoising
- Contrast enhancement using CLAHE (Contrast Limited Adaptive Histogram Equalization)

## 💡 Tips for Best Results

### For Clear Text Recognition:
- ✅ Write clearly and legibly
- ✅ Use good lighting when taking photos
- ✅ Avoid shadows and glare
- ✅ Keep the paper flat and camera steady
- ✅ Write one item per line
- ✅ Include quantities (e.g., "2 kg rice", "3 oil")

### Supported Formats:
- Item with quantity: "2 kg rice", "500g sugar"
- Item without quantity: "oil", "bread" (assumes 1 unit)

## 🌍 Supported Languages

- English
- Hindi (हिंदी)
- Kannada (ಕನ್ನಡ)
- Tamil (தமிழ்)
- Telugu (తెలుగు)
- Malayalam (മലയാളം)
- Bengali (বাংলা)
- Marathi (मराठी)
- Gujarati (ગુજરાતી)

## 📦 Pre-loaded Products

The system comes with common grocery items:
- Rice, Wheat, Sugar, Tea
- Oil, Dal, Salt, Milk
- Bread, Eggs
- And more...

Shopkeepers can add unlimited products!

## 🔮 Future Enhancements

- 🗣️ Voice assistant for reading items and total bill
- 💬 Chatbot for product-related queries
- 📱 QR code integration for quick scanning
- 🗄️ Database persistence (PostgreSQL)
- 👤 User authentication system
- 🧾 Order history and analytics
- 📧 Email/SMS bill sharing

## 🎯 Use Cases

1. **Local Grocery Stores**: Help customers prepare shopping lists in advance
2. **Language Barriers**: Assist customers who speak different languages
3. **Price Transparency**: Build trust between customers and shopkeepers
4. **Quick Billing**: Speed up the checkout process
5. **Inventory Management**: Track product availability

## 🏃 Getting Started

The app is already running! Simply:
1. Choose **Customer Mode** or **Shopkeeper Mode**
2. Follow the on-screen instructions
3. Start shopping smarter!

---

**Built with ❤️ to make shopping transparent and efficient**
