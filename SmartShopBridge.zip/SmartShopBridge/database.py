import os
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import bcrypt as bcrypt_lib

DATABASE_URL = os.getenv('DATABASE_URL')

engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    shopping_sessions = relationship("ShoppingSession", back_populates="user")

class Product(Base):
    __tablename__ = 'products'
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True, nullable=False)
    price = Column(Float, nullable=False)
    unit = Column(String, nullable=False)
    available = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ShoppingSession(Base):
    __tablename__ = 'shopping_sessions'
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    items = Column(JSON, nullable=False)
    total_amount = Column(Float, default=0.0)
    status = Column(String, default='draft')
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", back_populates="shopping_sessions")

def get_db():
    """Get database session"""
    db = SessionLocal()
    try:
        return db
    finally:
        pass

def init_db():
    """Initialize database tables"""
    Base.metadata.create_all(bind=engine)

def hash_password(password: str) -> str:
    """Hash password using bcrypt with salt"""
    salt = bcrypt_lib.gensalt()
    hashed = bcrypt_lib.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

def verify_password(password: str, password_hash: str) -> bool:
    """Verify password against bcrypt hash"""
    return bcrypt_lib.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))

def seed_initial_data():
    """Seed database with initial products and demo user (development only)"""
    db = SessionLocal()
    
    try:
        # Check if data already exists
        existing_products = db.query(Product).count()
        if existing_products > 0:
            return
        
        # Add default products
        default_products = [
            Product(name='rice', price=50, unit='kg', available=True),
            Product(name='wheat', price=40, unit='kg', available=True),
            Product(name='sugar', price=45, unit='kg', available=True),
            Product(name='tea', price=150, unit='kg', available=True),
            Product(name='oil', price=120, unit='liter', available=True),
            Product(name='dal', price=80, unit='kg', available=True),
            Product(name='salt', price=20, unit='kg', available=True),
            Product(name='milk', price=60, unit='liter', available=True),
            Product(name='bread', price=40, unit='piece', available=True),
            Product(name='eggs', price=6, unit='piece', available=True),
        ]
        
        for product in default_products:
            db.add(product)
        
        # Add demo shopkeeper user only in development (not production)
        # Production should create shopkeeper accounts through secure admin panel
        is_development = os.getenv('REPLIT_DEPLOYMENT') is None
        
        if is_development:
            existing_users = db.query(User).filter_by(username='shopkeeper').first()
            if not existing_users:
                shopkeeper = User(
                    username='shopkeeper',
                    password_hash=hash_password('shop123'),
                    role='shopkeeper'
                )
                db.add(shopkeeper)
                print("⚠️  DEVELOPMENT MODE: Demo shopkeeper account created (username: shopkeeper)")
        
        db.commit()
        print("Database seeded with initial data")
    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
    finally:
        db.close()

class DatabaseOperations:
    """Database operations wrapper"""
    
    @staticmethod
    def get_all_products():
        """Get all products"""
        db = SessionLocal()
        try:
            products = db.query(Product).all()
            return {p.name: {'price': p.price, 'unit': p.unit, 'available': p.available, 'id': p.id} 
                    for p in products}
        finally:
            db.close()
    
    @staticmethod
    def add_product(name, price, unit, available=True):
        """Add a new product"""
        db = SessionLocal()
        try:
            product = Product(name=name.lower(), price=price, unit=unit, available=available)
            db.add(product)
            db.commit()
            return True
        except Exception as e:
            db.rollback()
            return False
        finally:
            db.close()
    
    @staticmethod
    def update_product(name, price, unit, available):
        """Update an existing product"""
        db = SessionLocal()
        try:
            product = db.query(Product).filter_by(name=name).first()
            if product:
                product.price = price
                product.unit = unit
                product.available = available
                product.updated_at = datetime.utcnow()
                db.commit()
                return True
            return False
        except Exception as e:
            db.rollback()
            return False
        finally:
            db.close()
    
    @staticmethod
    def authenticate_user(username, password):
        """Authenticate user"""
        db = SessionLocal()
        try:
            user = db.query(User).filter_by(username=username).first()
            if user and verify_password(password, user.password_hash):
                return {'id': user.id, 'username': user.username, 'role': user.role}
            return None
        finally:
            db.close()
    
    @staticmethod
    def create_user(username, password, role='customer'):
        """Create a new user"""
        db = SessionLocal()
        try:
            user = User(
                username=username,
                password_hash=hash_password(password),
                role=role
            )
            db.add(user)
            db.commit()
            return True
        except Exception as e:
            db.rollback()
            return False
        finally:
            db.close()
    
    @staticmethod
    def save_shopping_session(user_id, items, total_amount, status='draft'):
        """Save shopping session"""
        db = SessionLocal()
        try:
            session = ShoppingSession(
                user_id=user_id,
                items=items,
                total_amount=total_amount,
                status=status
            )
            db.add(session)
            db.commit()
            return session.id
        except Exception as e:
            db.rollback()
            return None
        finally:
            db.close()

if __name__ == "__main__":
    init_db()
    seed_initial_data()
