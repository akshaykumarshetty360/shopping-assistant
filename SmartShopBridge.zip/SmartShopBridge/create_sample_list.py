from PIL import Image, ImageDraw, ImageFont
import random

def create_handwritten_sample():
    """Create a sample handwritten shopping list image"""
    
    # Create a white canvas
    width, height = 800, 600
    image = Image.new('RGB', (width, height), 'white')
    draw = ImageDraw.Draw(image)
    
    # Sample shopping list items
    items = [
        "2 kg rice",
        "1 kg sugar",
        "500g tea",
        "3 oil",
        "1 kg dal",
        "2 bread",
        "12 eggs",
        "1 liter milk"
    ]
    
    # Try to use a font that looks handwritten
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 40)
    except:
        font = ImageFont.load_default()
    
    # Add title
    draw.text((50, 30), "Shopping List", fill='black', font=font)
    draw.line([(50, 80), (750, 80)], fill='black', width=2)
    
    # Write items with slight variations to simulate handwriting
    y_position = 120
    for item in items:
        # Add slight random offset to simulate handwriting
        x_offset = random.randint(-5, 5)
        y_offset = random.randint(-3, 3)
        
        draw.text((80 + x_offset, y_position + y_offset), f"• {item}", fill='black', font=font)
        y_position += 55
    
    # Save the image
    image.save('sample_shopping_list.png')
    print("Sample shopping list image created: sample_shopping_list.png")

if __name__ == "__main__":
    create_handwritten_sample()
