# Overview

The Smart AI Shopping Assistant is a Streamlit-based web application that serves as a bridge between customers and shopkeepers. It uses OCR technology to digitize handwritten shopping lists, provides multi-language translation support, and offers real-time price calculations. The application operates in two modes: Customer Mode for uploading and processing shopping lists, and Shopkeeper Mode for inventory management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Application Framework
**Decision**: Streamlit for the web interface
**Rationale**: Provides rapid development of interactive Python web applications with minimal frontend code. Well-suited for data-centric applications with real-time updates.
**Trade-offs**: Limited customization compared to traditional web frameworks, but offers faster development and built-in state management.

## State Management
**Decision**: Streamlit session state for application state
**Rationale**: Manages user sessions, shopping cart items, product inventory, and mode switching (customer/shopkeeper) without requiring external state management libraries.
**Implementation**: Session state stores:
- Current mode (customer/shopkeeper)
- Product inventory with prices, units, and availability
- Extracted shopping list items
- Translated text cache

## OCR Pipeline
**Decision**: Pytesseract with OpenCV preprocessing
**Rationale**: Pytesseract provides robust text extraction, while OpenCV preprocessing improves accuracy on handwritten text.
**Preprocessing Steps**:
1. Grayscale conversion
2. Otsu's thresholating for binarization
3. Non-local Means Denoising for noise reduction
4. CLAHE (Contrast Limited Adaptive Histogram Equalization) for contrast enhancement

**Trade-offs**: CPU-intensive preprocessing, but significantly improves OCR accuracy on varied image quality.

## Translation System
**Decision**: Google Translator via deep-translator library
**Rationale**: Supports 8 Indian languages (Hindi, Kannada, Tamil, Telugu, Malayalam, Bengali, Marathi, Gujarati) plus English without requiring API keys or authentication.
**Implementation**: Real-time translation of extracted text to user's preferred language.

## Data Models
**Decision**: In-memory dictionary-based product catalog
**Rationale**: Simple structure suitable for prototype/MVP without database overhead.
**Product Schema**:
```python
{
  'product_name': {
    'price': float,
    'unit': string,  # kg, liter, piece
    'available': boolean
  }
}
```
**Limitations**: Data is not persisted between sessions; suitable for demo but would require database integration for production.

## Image Processing Pipeline
**Decision**: Multi-stage preprocessing before OCR
**Components**:
- PIL (Pillow) for image loading and basic manipulation
- OpenCV for advanced preprocessing
- NumPy for array operations

**Workflow**:
1. Image upload or camera capture
2. Preprocessing (grayscale → denoising → thresholding → contrast enhancement)
3. OCR extraction
4. Text parsing and item recognition
5. Price calculation based on inventory

## Dual-Mode Architecture
**Decision**: Single application with mode switching
**Rationale**: Reduces code duplication and maintains shared state between customer and shopkeeper views.
**Modes**:
- **Customer Mode**: Image upload, OCR processing, bill estimation
- **Shopkeeper Mode**: Inventory management, price updates, product additions

# External Dependencies

## Core Libraries
- **Streamlit**: Web application framework and UI components
- **OpenCV (cv2)**: Image preprocessing and computer vision operations
- **Pytesseract**: OCR engine wrapper for text extraction
- **Pillow (PIL)**: Image handling and manipulation
- **NumPy**: Numerical operations and array processing
- **Pandas**: Data structure for bill/inventory display

## Translation Service
- **deep-translator**: Google Translate API wrapper
  - No API key required
  - Supports 9 languages
  - Free tier usage

## System Dependencies
- **Tesseract OCR**: Must be installed at system level (pytesseract is Python wrapper)
- **Font files**: DejaVu fonts for sample list generation (`/usr/share/fonts/truetype/dejavu/`)

## Future Integration Points
- Database system (currently using in-memory storage)
- Authentication system (for shopkeeper access control)
- Payment gateway (for actual transactions)
- Cloud storage (for persistent image/data storage)