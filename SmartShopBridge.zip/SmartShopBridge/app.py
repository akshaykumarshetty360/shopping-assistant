import streamlit as st
import cv2
import numpy as np
from PIL import Image
import pytesseract
from deep_translator import GoogleTranslator
import pandas as pd
import re
from database import DatabaseOperations, init_db, seed_initial_data

# Initialize database
init_db()
seed_initial_data()

# Initialize session state
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False
if 'user' not in st.session_state:
    st.session_state.user = None
if 'mode' not in st.session_state:
    st.session_state.mode = 'customer'
if 'extracted_items' not in st.session_state:
    st.session_state.extracted_items = []
if 'translated_text' not in st.session_state:
    st.session_state.translated_text = ''
if 'cart_items' not in st.session_state:
    st.session_state.cart_items = []
if 'show_cart' not in st.session_state:
    st.session_state.show_cart = False

# Language options for translation
LANGUAGES = {
    'English': 'en',
    'Hindi': 'hi',
    'Kannada': 'kn',
    'Tamil': 'ta',
    'Telugu': 'te',
    'Malayalam': 'ml',
    'Bengali': 'bn',
    'Marathi': 'mr',
    'Gujarati': 'gu'
}

def preprocess_image(image):
    """Preprocess image for better OCR results"""
    img_array = np.array(image)
    
    if len(img_array.shape) == 3:
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    else:
        gray = img_array
    
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    denoised = cv2.fastNlMeansDenoising(thresh, None, 10, 7, 21)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    enhanced = clahe.apply(denoised)
    
    return enhanced

def extract_text_from_image(image):
    """Extract text from image using OCR"""
    try:
        processed_img = preprocess_image(image)
        text = pytesseract.image_to_string(processed_img)
        return text
    except Exception as e:
        st.error(f"Error extracting text: {str(e)}")
        return ""

def parse_shopping_list(text):
    """Parse the extracted text to identify items and quantities"""
    items = []
    lines = text.strip().split('\n')
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        match = re.match(r'(\d+\.?\d*)\s*([a-zA-Z]*)\s*(.+)', line)
        
        if match:
            quantity = float(match.group(1))
            unit = match.group(2).lower() if match.group(2) else ''
            item_name = match.group(3).strip().lower()
            
            items.append({
                'quantity': quantity,
                'unit': unit,
                'item': item_name,
                'original_line': line
            })
        else:
            item_name = line.lower()
            items.append({
                'quantity': 1,
                'unit': '',
                'item': item_name,
                'original_line': line
            })
    
    return items

def find_matching_product(item_name, products):
    """Find matching product from the database"""
    item_name = item_name.lower().strip()
    
    if item_name in products:
        return item_name
    
    for product in products.keys():
        if product in item_name or item_name in product:
            return product
    
    return None

def translate_text(text, target_language):
    """Translate text to target language"""
    try:
        if target_language == 'en' or not text:
            return text
        
        translator = GoogleTranslator(source='auto', target=target_language)
        translated = translator.translate(text)
        return translated
    except Exception as e:
        st.error(f"Translation error: {str(e)}")
        return text

def calculate_bill(items, products):
    """Calculate total bill based on recognized items"""
    bill_items = []
    total = 0
    
    for item in items:
        matched_product = find_matching_product(item['item'], products)
        
        if matched_product and products[matched_product]['available']:
            price = products[matched_product]['price']
            quantity = item['quantity']
            item_total = price * quantity
            total += item_total
            
            bill_items.append({
                'Item': matched_product.title(),
                'Quantity': quantity,
                'Unit': products[matched_product]['unit'],
                'Price/Unit': price,
                'Total': item_total,
                'Status': '✅ Available',
                'product_key': matched_product
            })
        else:
            bill_items.append({
                'Item': item['item'].title(),
                'Quantity': item['quantity'],
                'Unit': item['unit'],
                'Price/Unit': 0,
                'Total': 0,
                'Status': '❌ Not Available',
                'product_key': None
            })
    
    return bill_items, total

def text_to_speech(text):
    """Convert text to speech using browser's speech synthesis"""
    js_code = f"""
    <script>
        const text = {repr(text)};
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'en-IN';
        utterance.rate = 0.9;
        window.speechSynthesis.speak(utterance);
    </script>
    """
    st.components.v1.html(js_code, height=0)

# App UI
st.set_page_config(page_title="Smart Shopping Assistant", page_icon="🛒", layout="wide")

# Authentication
if not st.session_state.authenticated:
    st.title("🛒 Smart AI Shopping Assistant")
    st.markdown("*Please login or sign up to continue*")
    
    tab1, tab2 = st.tabs(["Login", "Sign Up"])
    
    with tab1:
        st.subheader("Login")
        username = st.text_input("Username", key="login_username")
        password = st.text_input("Password", type="password", key="login_password")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Login as Customer", width="stretch"):
                user = DatabaseOperations.authenticate_user(username, password)
                if user:
                    st.session_state.authenticated = True
                    st.session_state.user = user
                    st.session_state.mode = 'customer'
                    st.success(f"Welcome {user['username']}!")
                    st.rerun()
                else:
                    st.error("Invalid credentials")
        
        with col2:
            if st.button("Login as Shopkeeper", width="stretch"):
                user = DatabaseOperations.authenticate_user(username, password)
                if user and user['role'] == 'shopkeeper':
                    st.session_state.authenticated = True
                    st.session_state.user = user
                    st.session_state.mode = 'shopkeeper'
                    st.success(f"Welcome {user['username']}!")
                    st.rerun()
                else:
                    st.error("Invalid credentials or not a shopkeeper account")
        
        st.info("**Demo Credentials:**\n- Shopkeeper: username=`shopkeeper`, password=`shop123`")
    
    with tab2:
        st.subheader("Sign Up")
        new_username = st.text_input("Username", key="signup_username")
        new_password = st.text_input("Password", type="password", key="signup_password")
        role = st.selectbox("Account Type", ["customer", "shopkeeper"])
        
        if st.button("Create Account", width="stretch"):
            if new_username and new_password:
                success = DatabaseOperations.create_user(new_username, new_password, role)
                if success:
                    st.success("Account created! Please login.")
                else:
                    st.error("Username already exists or error creating account")
            else:
                st.error("Please fill all fields")
    
    st.stop()

# Main App (After Authentication)
st.title("🛒 Smart AI Shopping Assistant")
st.markdown(f"*Welcome, {st.session_state.user['username']} ({st.session_state.user['role']})*")

# Logout button
col1, col2, col3 = st.columns([3, 1, 1])
with col3:
    if st.button("🚪 Logout", width="stretch"):
        st.session_state.authenticated = False
        st.session_state.user = None
        st.session_state.extracted_items = []
        st.session_state.cart_items = []
        st.rerun()

st.divider()

# Mode selector
if st.session_state.user['role'] == 'shopkeeper':
    st.session_state.mode = 'shopkeeper'
else:
    st.session_state.mode = 'customer'

# Customer Mode
if st.session_state.mode == 'customer':
    st.header("📸 Upload Your Handwritten Shopping List")
    
    # Get products from database
    products = DatabaseOperations.get_all_products()
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("1️⃣ Capture/Upload List")
        
        upload_option = st.radio("Choose input method:", ["Upload Image", "Take Photo"])
        
        uploaded_file = None
        if upload_option == "Upload Image":
            uploaded_file = st.file_uploader("Upload handwritten list image", type=['png', 'jpg', 'jpeg'])
        else:
            uploaded_file = st.camera_input("Take a photo of your shopping list")
        
        if not uploaded_file and st.session_state.extracted_items:
            st.session_state.extracted_items = []
            st.session_state.translated_text = ''
        
        if uploaded_file:
            image = Image.open(uploaded_file)
            st.image(image, caption="Your Shopping List", width="stretch")
            
            st.subheader("2️⃣ Select Translation Language")
            target_language = st.selectbox(
                "Translate extracted text to:",
                options=list(LANGUAGES.keys()),
                index=0
            )
            
            if st.button("🔍 Extract & Process List", type="primary", width="stretch"):
                with st.spinner("Processing your shopping list..."):
                    extracted_text = extract_text_from_image(image)
                    
                    if extracted_text.strip():
                        st.success("✅ Text extracted successfully!")
                        
                        items = parse_shopping_list(extracted_text)
                        st.session_state.extracted_items = items
                        
                        if target_language != 'English':
                            translated = translate_text(extracted_text, LANGUAGES[target_language])
                            st.session_state.translated_text = translated
                        else:
                            st.session_state.translated_text = extracted_text
                        
                        bill_items, _ = calculate_bill(items, products)
                        st.session_state.cart_items = bill_items
                        st.session_state.show_cart = True
                    else:
                        st.error("❌ No text found. Please upload a clearer image.")
    
    with col2:
        if st.session_state.show_cart and st.session_state.cart_items:
            st.subheader("🛒 Shopping Cart")
            
            with st.expander("📝 Extracted Text", expanded=False):
                st.text(st.session_state.translated_text if st.session_state.translated_text else "No text extracted")
            
            st.subheader("Edit Your Cart")
            
            cart_df_data = []
            items_to_remove = []
            
            for idx, item in enumerate(st.session_state.cart_items):
                with st.container():
                    col_a, col_b, col_c, col_d = st.columns([3, 2, 2, 1])
                    
                    with col_a:
                        st.write(f"**{item['Item']}**")
                    
                    with col_b:
                        if item['Status'] == '✅ Available':
                            new_qty = st.number_input(
                                "Qty",
                                min_value=0.1,
                                value=float(item['Quantity']),
                                step=0.5,
                                key=f"qty_{idx}",
                                label_visibility="collapsed"
                            )
                            st.session_state.cart_items[idx]['Quantity'] = new_qty
                            st.session_state.cart_items[idx]['Total'] = new_qty * item['Price/Unit']
                        else:
                            st.write("N/A")
                    
                    with col_c:
                        if item['Status'] == '✅ Available':
                            st.write(f"₹{item['Price/Unit']}/{item['Unit']}")
                        else:
                            st.write(item['Status'])
                    
                    with col_d:
                        if st.button("🗑️", key=f"remove_{idx}"):
                            items_to_remove.append(idx)
            
            for idx in reversed(items_to_remove):
                st.session_state.cart_items.pop(idx)
            
            if items_to_remove:
                st.rerun()
            
            st.divider()
            
            total = sum([item['Total'] for item in st.session_state.cart_items if item['Status'] == '✅ Available'])
            
            col_final1, col_final2 = st.columns([1, 1])
            
            with col_final1:
                st.markdown(f"### **Total: ₹{total:.2f}**")
            
            with col_final2:
                if st.button("🔊 Read Bill Aloud", width="stretch"):
                    bill_text = f"Your total shopping bill is {total:.2f} rupees. Items: "
                    item_texts = [f"{item['Quantity']} {item['Unit']} of {item['Item']}" 
                                for item in st.session_state.cart_items 
                                if item['Status'] == '✅ Available']
                    bill_text += ", ".join(item_texts)
                    text_to_speech(bill_text)
                    st.success("🔊 Speaking...")
            
            if st.button("✅ Confirm & Save Cart", type="primary", width="stretch"):
                session_id = DatabaseOperations.save_shopping_session(
                    st.session_state.user['id'],
                    st.session_state.cart_items,
                    total,
                    'confirmed'
                )
                if session_id:
                    st.success("✅ Shopping cart saved successfully!")
                    
                    bill_df_data = []
                    for item in st.session_state.cart_items:
                        if item['Status'] == '✅ Available':
                            bill_df_data.append({
                                'Item': item['Item'],
                                'Quantity': f"{item['Quantity']} {item['Unit']}",
                                'Price/Unit': f"₹{item['Price/Unit']}",
                                'Total': f"₹{item['Total']:.2f}"
                            })
                    
                    if bill_df_data:
                        st.subheader("📄 Final Bill")
                        df = pd.DataFrame(bill_df_data)
                        st.dataframe(df, width="stretch", hide_index=True)
                else:
                    st.error("Error saving cart")

# Shopkeeper Mode
elif st.session_state.mode == 'shopkeeper':
    st.header("🏪 Shopkeeper Dashboard - Manage Inventory & Pricing")
    
    # Get products from database
    products = DatabaseOperations.get_all_products()
    
    tab1, tab2 = st.tabs(["📊 Current Inventory", "➕ Add/Update Products"])
    
    with tab1:
        st.subheader("Current Products & Prices")
        
        products_data = []
        for name, details in products.items():
            products_data.append({
                'Product': name.title(),
                'Price': f"₹{details['price']}",
                'Unit': details['unit'],
                'Available': '✅ Yes' if details['available'] else '❌ No'
            })
        
        df = pd.DataFrame(products_data)
        st.dataframe(df, width="stretch", hide_index=True)
        
        st.divider()
        
        st.subheader("Edit Existing Products")
        
        product_to_edit = st.selectbox(
            "Select product to edit:",
            options=list(products.keys()),
            format_func=lambda x: x.title()
        )
        
        if product_to_edit:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                new_price = st.number_input(
                    "Price (₹)",
                    min_value=0.0,
                    value=float(products[product_to_edit]['price']),
                    step=1.0
                )
            
            with col2:
                new_unit = st.text_input(
                    "Unit",
                    value=products[product_to_edit]['unit']
                )
            
            with col3:
                new_availability = st.checkbox(
                    "Available",
                    value=products[product_to_edit]['available']
                )
            
            if st.button("💾 Update Product", type="primary"):
                success = DatabaseOperations.update_product(
                    product_to_edit,
                    new_price,
                    new_unit,
                    new_availability
                )
                if success:
                    st.success(f"✅ {product_to_edit.title()} updated successfully!")
                    st.rerun()
                else:
                    st.error("Error updating product")
    
    with tab2:
        st.subheader("Add New Product")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            new_product_name = st.text_input("Product Name").lower().strip()
        
        with col2:
            new_product_price = st.number_input("Price (₹)", min_value=0.0, step=1.0)
        
        with col3:
            new_product_unit = st.text_input("Unit (kg/liter/piece)")
        
        new_product_available = st.checkbox("Available in stock", value=True)
        
        if st.button("➕ Add Product", type="primary"):
            if new_product_name and new_product_price > 0 and new_product_unit:
                success = DatabaseOperations.add_product(
                    new_product_name,
                    new_product_price,
                    new_product_unit,
                    new_product_available
                )
                if success:
                    st.success(f"✅ {new_product_name.title()} added successfully!")
                    st.rerun()
                else:
                    st.error("Product already exists or error adding product")
            else:
                st.error("Please fill all fields correctly.")

# Footer
st.divider()
st.markdown("""
<div style='text-align: center; color: gray; padding: 20px;'>
    <p>🤖 Powered by AI • Making shopping transparent and efficient</p>
    <p>OCR • Translation • Real-time Pricing • Voice Assistant</p>
</div>
""", unsafe_allow_html=True)
